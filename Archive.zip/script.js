

var forHim = [
  {"product": "https://dosrgfkou9o2m.cloudfront.net/api/images/Cardshop/1/product/NWCHLB4-AR/6?subscription-key=b00894e69b9f499cb2beb782cf79e5be&w=680",
   "url": "https://www.moonpig.com/uk/Gift/Flowers/Detail/NWCHLB4-AR/",
   "name": "Lanson Black Label & Exclusive Champagne Stopper!",
   "price": "£36.00"
  },

  {"product": "https://dosrgfkou9o2m.cloudfront.net/api/images/Cardshop/1/product/HAMP34/2?subscription-key=b00894e69b9f499cb2beb782cf79e5be&w=680",
   "url": "https://www.moonpig.com/uk/Gift/Flowers/Detail/HAMP34/",
   "name": "Thornton & France Cheese Lovers Wicker Tray",
   "price": "£20.00"
  },

  {"product": "https://dosrgfkou9o2m.cloudfront.net/api/images/Cardshop/1/product/NWSLG2/1?subscription-key=b00894e69b9f499cb2beb782cf79e5be&w=680",
   "url": "https://www.moonpig.com/uk/Gift/Flowers/Detail/NWSLG2/",
   "name": "Freedom Award Winning British Lagers Gift Set",
   "price": "£22.00"
  },

  {"product": "https://dosrgfkou9o2m.cloudfront.net/api/images/Cardshop/1/product/HAMP45/2?subscription-key=b00894e69b9f499cb2beb782cf79e5be&w=680",
   "url": "https://www.moonpig.com/uk/Gift/Flowers/Detail/HAMP45/",
   "name": "Christmas Favourites Filled Santa Sack",
   "price": "£35.00"
  },

  {"product": "https://dosrgfkou9o2m.cloudfront.net/api/images/Cardshop/1/product/BOX440/3?subscription-key=b00894e69b9f499cb2beb782cf79e5be&w=680",
   "url": "https://www.moonpig.com/uk/Gift/Flowers/Detail/BOX440/",
   "name": "The Curry Night Box",
   "price": "£35.00"
  }
]  

var forHer = [
  {"product": "http://assets.moonpig.com/api/images/Cardshop/1/product/NWCHLR5-AR/3?subscription-key=b00894e69b9f499cb2beb782cf79e5be&w=680",
   "url": "https://www.moonpig.com/uk/gifts/lanson-rose-champagne-exclusive-champagne-stopper-new/nwchlr5-ar/",
   "name": " Lanson Rose Champagne & Exclusive Champagne Stopper - NEW!",
   "price": "£40.00"
  },

  {"product": "http://assets.moonpig.com/api/images/Cardshop/1/product/BEAU96/2?subscription-key=b00894e69b9f499cb2beb782cf79e5be&w=680",
   "url": "https://www.moonpig.com/uk/gifts/vintage-co-fabric-flowers-bath-flowers/beau96/",
   "name": "Vintage & Co Fabric & Flowers Bath flowers",
   "price": "£12.00"
  },

  {"product": "http://assets.moonpig.com/api/images/Cardshop/1/product/HAMP32/2?subscription-key=b00894e69b9f499cb2beb782cf79e5be&w=680",
   "url": "https://www.moonpig.com/uk/gifts/thornton-france-tea-time-treats-wicker-tray/hamp32/",
   "name": "Thornton & France Tea Time Treats Wicker Tray",
   "price": "£20.00"
  },

  {"product": "http://assets.moonpig.com/api/images/Cardshop/1/product/SFT568/2?subscription-key=b00894e69b9f499cb2beb782cf79e5be&w=680",
   "url": "https://www.moonpig.com/uk/gifts/cozy-plush-pug/sft568/",
   "name": "Warmies Microwavable Cozy Pug",
   "price": "£12.00"
  },

  {"product": "http://assets.moonpig.com/api/images/Cardshop/1/product/CHOC629/2?subscription-key=b00894e69b9f499cb2beb782cf79e5be&w=680",
   "url": "https://www.moonpig.com/uk/gifts/montezuma-christmas-truffle-collection/choc629/",
   "name": "Montezuma Christmas Truffle Collection",
   "price": "£12.00"
  }
]

var forKids = [
  {"product": "http://assets.moonpig.com/api/images/Cardshop/1/product/KID02/2?subscription-key=b00894e69b9f499cb2beb782cf79e5be&w=680",
   "url": "https://www.moonpig.com/uk/gifts/little-miss-princess-grow-your-own-bouquet/kid02/",
   "name": "Little Miss Princess Grow Your Own Bouquet",
   "price": "£10.00"
  },

  {"product": "http://assets.moonpig.com/api/images/Cardshop/1/product/KID54/2?subscription-key=b00894e69b9f499cb2beb782cf79e5be&w=680",
   "url": "https://www.moonpig.com/uk/gifts/build-your-own-batmobile-new/kid54/",
   "name": "Build Your Own Batmobile",
   "price": "£8.00"
  },

  {"product": "http://assets.moonpig.com/api/images/Cardshop/1/product/KID27/2?subscription-key=b00894e69b9f499cb2beb782cf79e5be&w=680",
   "url": "https://www.moonpig.com/uk/gifts/bakedin-chocolate-brownie-baking-kit/kid27/",
   "name": "Bakedin Chocolate Brownie Baking Kit",
   "price": "£12.00"
  },

  {"product": "http://assets.moonpig.com/api/images/Cardshop/1/product/SFT544/2?subscription-key=b00894e69b9f499cb2beb782cf79e5be&w=680",
   "url": "https://www.moonpig.com/uk/gifts/minons-bob-holding-a-bear-new/sft544/",
   "name": "Minon's Bob Holding a Bear",
   "price": "£15.00"
  },

  {"product": "http://assets.moonpig.com/api/images/Cardshop/1/product/KID07/2?subscription-key=b00894e69b9f499cb2beb782cf79e5be&w=680",
   "url": "https://www.moonpig.com/uk/gifts/train-in-a-tin/kid07/",
   "name": "Train in a Tin",
   "price": "£10.00"
  }
]

var gift = document.getElementById("gift");
var recipient = document.getElementById("recipient");
var generateBtn = document.getElementById("generate");
var giftPrice = document.getElementById("price");
var giftName = document.getElementById("name");
var giftCopy = document.getElementById("giftCopy");
var shopBtn = document.getElementById("shop");
var category;
var n;



  generateBtn.addEventListener('click', function(){
    generateGift();
  })

  recipient.addEventListener('change', function(){
    if(recipient.value !== 'Select an option'){
      generateBtn.classList.remove('disabled');
      }
    else{
      generateBtn.classList.add('disabled');
    }
  })



function generateGift(){
  
  var selection = recipient.value;

  if (selection == 'dd_forHim'){
    category = forHim;
  }
  else if (selection == 'dd_forHer'){
    category = forHer;
  }

  else if (selection == 'dd_forKids'){
    category = forKids;
  }
  else{
    category = "";
    generateBtn.classList.add('disabled');
  }

  random();
  updatePage();
  
}

function random(){
  n = Math.floor((Math.random() * (category.length)));
}

function updatePage(){
  gift.src = category[n].product;
  giftCopy.classList.remove('hidden');
  giftPrice.innerHTML = category[n].price;
  giftName.innerHTML = category[n].name;
  shopBtn.classList.remove('hidden');
  shopBtn.addEventListener('click', function(){
    window.open(category[n].url)
  })
}







